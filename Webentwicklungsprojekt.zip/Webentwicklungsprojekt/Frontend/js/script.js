
console.log("Shirtastic Frontend geladen.");
