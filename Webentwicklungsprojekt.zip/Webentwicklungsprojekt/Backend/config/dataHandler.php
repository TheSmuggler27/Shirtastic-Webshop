<?php
require_once 'dbaccess.php';

/**
 * Beispiel: Funktion zum Abrufen aller Produkte
 */
function getProducts() {
    global $pdo;
    $sql = "SELECT * FROM products";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Hier können weitere Funktionen für den Datenaustausch zwischen Frontend und Backend ergänzt werden.
?>
