<?php
// Datenbank-Zugangsdaten
$host = 'localhost';
$dbname = 'shirtastic';
$user = 'root';
$password = '';

// Versuche die Verbindung zur Datenbank aufzubauen
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Verbindung erfolgreich
} catch (PDOException $e) {
    // Fehlermeldung ausgeben und Script beenden
    echo "Verbindung fehlgeschlagen: " . $e->getMessage();
    exit();
}
?>
